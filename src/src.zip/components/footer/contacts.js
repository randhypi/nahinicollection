import React from "react";

const Contacts = () => {
  return <div className="contacts"></div>;
};

export default Contacts;
