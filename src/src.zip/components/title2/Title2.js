import React from "react";
import Carousel from "./Carousel";

const Title2 = () => {
  return (
    <section id="title2">
      <Carousel />
    </section>
  );
};

export default Title2;
